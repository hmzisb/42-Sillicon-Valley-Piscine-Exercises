/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: haahmed <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/30 22:11:56 by haahmed           #+#    #+#             */
/*   Updated: 2019/03/30 22:15:43 by haahmed          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int fac;
	int i;

	fac = 1;
	if (nb < 0 || nb > 12)
		return (0);
	if (nb == 0 || nb == 1)
		fac = 1;
	if (nb > 1)
	{
		i = 1;
		while (i <= nb)
		{
			fac = fac * i;
			i++;
		}
	}
	return (fac);
}
